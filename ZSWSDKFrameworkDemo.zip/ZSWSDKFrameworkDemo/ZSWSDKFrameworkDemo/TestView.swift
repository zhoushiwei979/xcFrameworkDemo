//
//  TestView.swift
//  ZSWSDKFramework
//
//  Created by 周诗玮 on 2025/3/14.
//

import UIKit

/// demo测试view
public class TestView: UIView {
    
    /// 初始化
    override init(frame: CGRect) {
        super.init(frame: frame)
        makeUI()
    }
    
    ///
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /// UI
    func makeUI() {
        addSubview(button)
        button.frame = CGRectMake(0, 0, 50, 50)
    }
    
    /// 点击按钮
    @objc func buttonTapAction() {
        print("点击按钮 点击按钮 点击按钮")
    }
    
    /// 按钮
    lazy var button: UIButton = {
        let button = UIButton()
        button.backgroundColor = .red
        button.setTitleColor(.white, for: .normal)
        button.setTitle("点击", for: .normal)
        button.addTarget(self, action: #selector(buttonTapAction), for: .touchUpInside)
        return button
    }()
    
}
