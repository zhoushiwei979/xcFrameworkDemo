//
//  ViewController.swift
//  ZSWSDKFramework
//
//  Created by 周诗玮 on 2025/3/23.
//

import UIKit
import ZSWSDKFrameworkDemo

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        view.backgroundColor = .white
        
        let testView = TestView()
        testView.frame = CGRectMake(100, 100, 100, 100)
        view.addSubview(testView)
    }
}

